# ! /bin/sh

# Axel Download Manager
# sudo apt-get install axel

# Aria2 Download Manager
sudo apt-get -y install axel aria2 curl
