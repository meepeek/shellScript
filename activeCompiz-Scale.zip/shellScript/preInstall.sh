# ! /bin/sh

sudo ./preInstall/general.sh
